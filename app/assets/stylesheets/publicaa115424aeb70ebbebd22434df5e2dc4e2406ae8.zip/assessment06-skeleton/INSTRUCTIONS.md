# Assessment06 CSS Instructions

You have 1 hour to write the CSS to make the page look like the provided design.

There are three images provided of the design:
1. `design-final.png`
2. `design-annotated.png`
3. `design-outline.png`

There is a write up `design-specification.txt` which includes color and type specifications.

A semantically marked up HTML document `index.html` is provided. Carefully read through this before you start, so you know what you're working with.

You need only edit the `style.css` file.

All CSS selectors are provided for your convenience. You may not need all of them. You may add additional selectors, as you see fit.

There is a small overlay dropdown in the top left corner of `index.html`. You may use this to show an outline overlay on top of your page to make sure your design lines up correctly. Please use Chrome at 100% zoom level.

After 1 hour (or upon completion), rename the `assessment06` folder to `assessment06-#{firstname}-#{lastname}`. Then zip the folder and email it to your instructor.

If you have any problems getting set up and started, ask your
instructor for help.

Though you should be well prepared, you may use the general internet and the following resources.
- http://www.w3.org/TR/CSS21/propidx.html
- https://developer.mozilla.org/en-US/docs/Web/CSS/Reference
- http://css-tricks.com/almanac/

You can do it!

